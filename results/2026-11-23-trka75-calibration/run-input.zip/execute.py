import json, shutil, sys, traceback
from pathlib import Path
from time import perf_counter
base=Path(__file__).resolve().parent
root=base/'results'
root.mkdir()
(root/'runtime').mkdir()
sys.path.insert(0,str(base/'src/af2_filter'))
import calibration_workflow as w
from workflow import prepare_runtime,run_logged
t=perf_counter()
try:
    shutil.copytree(base/'inputs/trka',root/'inputs')
    for name in ('settings.json','source.json'):
        shutil.copy(base/name,root/name)
    python, upstream, env=prepare_runtime(root)
    release=w.fetch_release(Path('/content/trka88_af2_v0_3_0'),root/'runtime/release.log',env)
    run_logged([python,base/'src/af2_filter/calibration.py',root,release,upstream],root/'runtime/calibration.log',env)
except BaseException:
    (root/'runtime/failure.txt').write_text(traceback.format_exc())
    raise
finally:
    (root/'runtime/timing.json').write_text(json.dumps({'seconds':perf_counter()-t}))
    shutil.make_archive('/content/trka75-results','zip',root)
